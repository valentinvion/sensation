<footer>
  <p>Copyright Valentin Vion & Yohan Bochet 2017</p>
  <?php wp_footer();?>
</footer>
</body>
</html>
