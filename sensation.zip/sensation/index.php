<?php wp_redirect(site_url());
exit;
