<?php
/*
Template Name: propos
*/
get_header();?>
<p><?php the_content();?></p>
<?php get_footer('footer.php');?>
