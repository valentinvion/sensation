<?php /*
Template Name : stats_standard_deviation
*/
get_header(); ?>

<h1><?phpthe_title();?></h1>

<?php while(have_post()): the post();?>

  <div>
    <?php the content()?>
  </div>

<?php endwhile;

get_footer();
