<?php
/*
Template Name: actualites
*/
get_header();

$args = array (
  'post_type'=>'post');





/* the loop */
$query = new WP_Query($args);

if ($query->have_posts()):while($query->have_posts()):$query->the_post();?>
<h2><a href= "<?php the_permalink();?>"><?php the_title();?></a></h2>
<p><?php the_excerpt();?></p>
<p class="signature">Posté le <?php the_time('j F Y à H\hi');?> par <?php the_author_posts_link();?></p>
<?php endwhile; endif;?>

<?php get_footer('footer.php');?>
