<?php get_header('header.php');?>

<?php the_post();?>
<!--<h2><a href= "<?php the_permalink();?>"><?php the_title();?></a></h2>-->
<div class="">
  <?php the_content(); ?>
</div>



<?php
  if (comments_open() || get_comments_number()):
    comments_template();
    endif
    ?>
 <?php comments_number('aucun commentaire','un commentaire','% commentaires');?>



<p class="signature">Posté le <?php the_time('j F Y à H\hi');?> par <?php the_author_posts_link();?></p>
<?php get_footer('footer.php');?>
